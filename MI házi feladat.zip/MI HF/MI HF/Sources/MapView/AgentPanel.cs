﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace MI_HF
{
    public delegate void ToggleSearchStateVisibleDelegate(int id);

    public partial class AgentPanel : UserControl
    {
        private SearchState state;
        private bool goalReached;
        public event ToggleSearchStateVisibleDelegate ToggleSearchStateVisibleEvent;

        public AgentPanel()
        {
            InitializeComponent();
            goalReached = false;

            if (AgentHandler.speedLimitEnabled)
            {
                this.label_constRunTime.Visible = this.label_constRunTime.Enabled = true;
                this.label_runTime.Visible = this.label_runTime.Enabled = true;
            }
        }

        public void Init(AgentHandlerConstructionParameters par)
        {
            this.label_agentName.ForeColor = par.color;
            this.label_agentName.Text = AgentTypeToString(par.type);

            Update();
        }

        public void ProgressChanged(SearchState state)
        {
            this.state = state;
            Invalidate();
        }

        public void GoalReached()
        {
            if (!goalReached)
            {
                try
                {
                    if (this.InvokeRequired)
                        Invoke(new GoalReachedDelegate(this.GoalReached));
                    else
                        this.label_agentName.Text += " (kész)";
                    goalReached = true;
                }
                catch (ObjectDisposedException) { }
            }
        }

        private static string AgentTypeToString(AgentType p)
        {
            switch (p)
            {
                case AgentType.Omniscient :
                    return "Omniscient";
                case AgentType.AStarOptimistic :
                    return "Optimista A*";
                case AgentType.AStarPessimistic :
                    return "Pesszimista A*";
                case AgentType.DStarFocused :
                    return "Focused D*";
                case AgentType.DStarLite :
                    return "D* Lite";
                case AgentType.DStarOriginal :
                    return "Original D*";
                default :
                    throw new System.ComponentModel.InvalidEnumArgumentException();
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            if (state != null)
            {
                this.label_pathCost.Text = state.distance.ToString();
                this.label_procTime.Text = state.procTime.ToString(@"mm\:ss\.fff");
                this.label_stepNumber.Text = state.stepNumber.ToString();

                if (AgentHandler.speedLimitEnabled)
                    this.label_runTime.Text = state.runTime.ToString(@"mm\:ss\.fff");
            }
        }

        private void checkBox_visible_CheckedChanged(object sender, EventArgs e)
        {
            if (state != null)
                ToggleSearchStateVisibleEvent(state.id);
        }
    }
}
