﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace MI_HF
{
    static class Program
    {
        public static object searchStateSyncroot = new object();

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Application.Run(new settingsForm());
        }
    }
}
